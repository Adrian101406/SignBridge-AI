from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from signbridge_mcie import AIEnhancedMCIE, ConversationState, MCIERuntime
from signbridge_mcie.mock_llm import DeterministicMockLLM
from signbridge_mcie.recognizer_adapter import process_recognizer_result


def base_entities():
    return {
        "symptoms": [], "body_parts": [], "medications": [],
        "quantity": None, "frequency": None, "timing": None,
        "duration": {"quantity": None, "unit": None},
    }


def mock_response(intent="GENERAL_COMMUNICATION", concepts=None, en="OK", ms="OK", **kwargs):
    payload = {
        "intent": intent,
        "medical_concepts": concepts or [],
        "entities": base_entities(),
        "simplified_text_en": en,
        "simplified_text_ms": ms,
        "context_used": False,
        "evidence": [],
        "uncertainty": [],
        "requires_confirmation": False,
    }
    payload.update(kwargs)
    return payload


def general_result(gloss="hari", confidence=0.90, margin=0.70):
    return {
        "recognizer": "SignBridge_General_Recognizer_V1",
        "domain": "general",
        "top1": {"class_id": 45, "gloss": gloss, "english": "day", "confidence": confidence},
        "top_k": [
            {"rank": 1, "class_id": 45, "gloss": gloss, "english": "day", "confidence": confidence},
            {"rank": 2, "class_id": 52, "gloss": "jam", "english": "hour", "confidence": max(0.0, confidence - margin)},
        ],
        "confidence_margin": margin,
        "quality": {"hand_presence": 0.95, "raw_frames": 70, "trimmed_frames": 55},
    }


def number_result(value="2", confidence=0.92, margin=0.70):
    return {
        "recognizer": "SignBridge_Number_Recognizer_V1",
        "domain": "number",
        "top1": {"class_id": int(value), "gloss": value, "english": value, "confidence": confidence},
        "top_k": [
            {"rank": 1, "class_id": int(value), "gloss": value, "english": value, "confidence": confidence},
            {"rank": 2, "class_id": 3, "gloss": "3", "english": "3", "confidence": max(0.0, confidence - margin)},
        ],
        "confidence_margin": margin,
        "quality": {"hand_presence": 0.96, "raw_frames": 50, "trimmed_frames": 48},
    }


class TestSignBridgeMCIE(unittest.TestCase):
    def make_runtime(self, response=None):
        llm = DeterministicMockLLM(response or mock_response())
        mcie = AIEnhancedMCIE(llm)
        return MCIERuntime(mcie), llm

    def test_confirmed_doctor_chest_pain(self):
        response = mock_response(
            intent="SYMPTOM_CHECK",
            concepts=["CHEST_PAIN"],
            en="Do you have chest pain?",
            ms="Adakah anda mengalami sakit dada?",
            evidence=[{"concept": "CHEST_PAIN", "source": "sakit dada"}],
        )
        runtime, _ = self.make_runtime(response)
        payload = {
            "success": True,
            "source": "doctor_speech",
            "transcript": "You ada sakit dada tak?",
            "medical_validation": {
                "status": "CONFIRM",
                "risk_level": "MEDICAL",
                "detected_concepts": ["CHEST_PAIN"],
            },
            "confirmation_status": "CONFIRMED",
        }
        out = runtime.process_doctor_asr_payload(payload)
        self.assertEqual(out["source"], "doctor_speech")
        self.assertEqual(out["interpretation"]["intent"], "SYMPTOM_CHECK")
        self.assertIn("CHEST_PAIN", out["interpretation"]["medical_concepts"])
        self.assertEqual(out["safety"]["decision"], "ACCEPT")

    def test_unconfirmed_asr_is_blocked_before_mcie(self):
        runtime, _ = self.make_runtime()
        payload = {
            "success": True,
            "transcript": "You ada sakit dada tak?",
            "medical_validation": {"status": "CONFIRM"},
            "confirmation_status": "PENDING",
        }
        out = runtime.process_doctor_asr_payload(payload)
        self.assertEqual(out["safety"]["decision"], "CONFIRM")
        self.assertFalse(out["ready_for_output"])

    def test_specific_headache_duration_context(self):
        response = mock_response(
            intent="SYMPTOM_DURATION",
            concepts=["HEADACHE"],
            en="How long have you had a headache?",
            ms="Berapa lama anda mengalami sakit kepala?",
            evidence=[{"concept": "HEADACHE", "source": "sakit kepala"}],
        )
        runtime, _ = self.make_runtime(response)
        payload = {
            "success": True,
            "transcript": "Sakit kepala sejak bila?",
            "medical_validation": {"status": "PASS"},
            "confirmation_status": "NOT_REQUIRED",
        }
        out = runtime.process_doctor_asr_payload(payload)
        self.assertEqual(out["interpretation"]["medical_concepts"], ["HEADACHE"])
        self.assertEqual(runtime.state.current_symptom, "HEADACHE")
        self.assertEqual(runtime.state.expected_response_type, "DURATION")
        self.assertEqual(runtime.expected_recognizer_domains(), ["number", "general"])

    def test_contextual_reranking_stays_inside_top_k(self):
        state = ConversationState(last_doctor_intent="SYMPTOM_LOCATION")
        result = {
            "recognizer": "SignBridge_Medical_Recognizer_V2",
            "domain": "medical",
            "top1": {"class_id": 28, "gloss": "Demam", "english": "Fever", "confidence": 0.84},
            "top_k": [
                {"rank": 1, "class_id": 28, "gloss": "Demam", "english": "Fever", "confidence": 0.84},
                {"rank": 2, "class_id": 39, "gloss": "Perut", "english": "Stomach", "confidence": 0.76},
                {"rank": 3, "class_id": 23, "gloss": "Batuk", "english": "Cough", "confidence": 0.10},
            ],
            "confidence_margin": 0.08,
            "decision": "ACCEPT",
            "quality": {"hand_presence": 0.95, "face_presence": 0.98},
        }
        token = process_recognizer_result(result, state)
        self.assertEqual(token["concept"], "ABDOMEN")
        self.assertTrue(token["selection_changed"])
        self.assertTrue(token["requires_confirmation"])
        returned = {c["concept"] for c in token["candidates"]}
        self.assertIn(token["concept"], returned)

    def test_medical_number_requires_confirmation(self):
        runtime, _ = self.make_runtime()
        token = runtime.preview_patient_sign(number_result(), number_is_medical=True)
        self.assertTrue(token["requires_confirmation"])
        not_added = runtime.accept_patient_sign(token, human_confirmed=False)
        self.assertFalse(not_added["success"])
        added = runtime.accept_patient_sign(token, human_confirmed=True)
        self.assertTrue(added["success"])

    def test_sentence_buffer_duration_finish(self):
        runtime, _ = self.make_runtime()
        runtime.state.last_doctor_intent = "SYMPTOM_DURATION"
        runtime.state.current_symptom = "HEADACHE"
        runtime.state.expected_response_type = "DURATION"
        runtime.start_patient_sentence()

        n = runtime.preview_patient_sign(number_result(), number_is_medical=True, number_confirmed=True)
        self.assertTrue(runtime.accept_patient_sign(n)["success"])
        day = runtime.preview_patient_sign(general_result())
        self.assertTrue(runtime.accept_patient_sign(day)["success"])

        preview = runtime.patient_sentence_preview()
        self.assertEqual(preview["gloss_sequence"], ["2", "hari"])
        self.assertEqual(preview["concept_sequence"], ["2", "DAY"])

        out = runtime.finish_patient_sentence()
        self.assertEqual(out["interpretation"]["intent"], "SYMPTOM_DURATION")
        self.assertEqual(out["interpretation"]["entities"]["duration"], {"quantity": 2, "unit": "DAY"})
        self.assertEqual(out["output"]["simplified_text_en"], "I have had a headache for 2 days.")
        self.assertEqual(runtime.patient_sentence_preview()["sign_count"], 0)

    def test_llm_cannot_invent_unsupported_patient_concept(self):
        response = mock_response(
            intent="SYMPTOM_REPORT",
            concepts=["FEVER", "CANCER"],
            en="I have a fever.",
            ms="Saya demam.",
        )
        runtime, _ = self.make_runtime(response)
        out = runtime.mcie.patient_bim(
            gloss_sequence=["Demam"],
            concept_sequence=["FEVER"],
            state=runtime.state,
        )
        self.assertEqual(out["interpretation"]["medical_concepts"], ["FEVER"])
        self.assertTrue(out["safety"]["requires_confirmation"])

    def test_critical_medical_sign_is_confirmation_gated(self):
        state = ConversationState(last_doctor_intent="MEDICATION_QUERY")
        result = {
            "recognizer": "SignBridge_Medical_Recognizer_V2",
            "domain": "medical",
            "top1": {"class_id": 36, "gloss": "Pil", "english": "Pill", "confidence": 0.91},
            "top_k": [
                {"rank": 1, "class_id": 36, "gloss": "Pil", "english": "Pill", "confidence": 0.91},
                {"rank": 2, "class_id": 35, "gloss": "Krim", "english": "Cream", "confidence": 0.05},
            ],
            "confidence_margin": 0.86,
            "decision": "ACCEPT",
            "quality": {"hand_presence": 0.98, "face_presence": 0.98},
        }
        token = process_recognizer_result(result, state)
        self.assertTrue(token["requires_confirmation"])
        self.assertIn("Critical medical concept", " ".join(token["decision_reasons"]))

    def test_finish_empty_sentence_is_rejected(self):
        runtime, _ = self.make_runtime()
        out = runtime.finish_patient_sentence()
        self.assertFalse(out["success"])


if __name__ == "__main__":
    unittest.main(verbosity=2)

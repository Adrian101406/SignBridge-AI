# Local model directory

Do not commit large model weights to this source-code repository unless your team intentionally uses Git LFS and has permission to redistribute them.

For offline runtime, copy the complete local model directory here, for example:

```text
models/
└── Qwen3-4B-Instruct-2507/
```

The code uses `local_files_only=True` and does not need Wi-Fi after the model and Python dependencies have been installed locally.

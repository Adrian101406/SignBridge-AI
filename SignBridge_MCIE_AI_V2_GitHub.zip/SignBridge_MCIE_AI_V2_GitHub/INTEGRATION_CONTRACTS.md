# SignBridge MCIE Integration Contracts

## Doctor ASR -> MCIE

```json
{
  "success": true,
  "source": "doctor_speech",
  "transcript": "You ada sakit dada tak?",
  "asr_information": {
    "model": "mesolitica/malaysian-whisper-small-v3",
    "status": "OK"
  },
  "medical_validation": {
    "status": "CONFIRM",
    "risk_level": "MEDICAL",
    "detected_concepts": ["CHEST_PAIN"]
  },
  "confirmation_status": "CONFIRMED"
}
```

MCIE blocks an ASR payload requiring confirmation until `confirmation_status` is `CONFIRMED`.

## Medical Recognizer V2 -> MCIE

```json
{
  "recognizer": "SignBridge_Medical_Recognizer_V2",
  "domain": "medical",
  "top1": {
    "class_id": 28,
    "gloss": "Demam",
    "english": "Fever",
    "confidence": 0.82
  },
  "top_k": [],
  "confidence_margin": 0.72,
  "decision": "ACCEPT",
  "quality": {
    "hand_presence": 0.95,
    "face_presence": 0.99
  }
}
```

## General Recognizer V1 -> MCIE

```json
{
  "recognizer": "SignBridge_General_Recognizer_V1",
  "domain": "general",
  "top1": {
    "class_id": 45,
    "gloss": "hari",
    "english": "day",
    "confidence": 0.91
  },
  "top_k": [],
  "confidence_margin": 0.80,
  "quality": {
    "hand_presence": 0.95
  }
}
```

## Number Recognizer V1 -> MCIE

```json
{
  "recognizer": "SignBridge_Number_Recognizer_V1",
  "domain": "number",
  "top1": {
    "class_id": 2,
    "gloss": "2",
    "english": "2",
    "confidence": 0.93
  },
  "top_k": [],
  "confidence_margin": 0.81,
  "quality": {
    "hand_presence": 0.96,
    "raw_frames": 60,
    "trimmed_frames": 58
  }
}
```

## MCIE output

```json
{
  "success": true,
  "source": "patient_bim",
  "input": {
    "gloss_sequence": ["2", "hari"],
    "concept_sequence": ["2", "DAY"]
  },
  "interpretation": {
    "intent": "SYMPTOM_DURATION",
    "medical_concepts": ["HEADACHE"],
    "entities": {
      "symptom": "HEADACHE",
      "duration": {
        "quantity": 2,
        "unit": "DAY"
      }
    },
    "context_used": true
  },
  "output": {
    "simplified_text_en": "I have had a headache for 2 days.",
    "simplified_text_ms": "Saya mengalami sakit kepala selama 2 hari."
  },
  "safety": {
    "decision": "ACCEPT",
    "requires_confirmation": false,
    "requires_retry": false,
    "reasons": []
  },
  "ready_for_output": true,
  "ready_for_translation": true
}
```

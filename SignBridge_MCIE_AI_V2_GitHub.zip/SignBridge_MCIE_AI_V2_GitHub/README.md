# SignBridge AI-Enhanced MCIE V2

Medical Conversation Intelligence Engine (MCIE) for the SignBridge offline healthcare communication prototype.

This repository contains **the MCIE component only**. It does not contain the teammates' ASR model, BIM recognition models, Unity avatar assets, or their training datasets. Instead, MCIE integrates with those components through documented JSON-style interfaces.

## 1. Scope of this repository

MCIE sits between AI perception and downstream translation/display:

```text
Doctor speech / Patient BIM
            |
            v
       AI Perception
   ASR / BIM recognizers
            |
            v
  AI-Enhanced MCIE V2
  - rule-based anchor
  - local LLM reasoning
  - evidence validation
  - Top-K contextual handling
  - conversation context
  - sentence buffer
  - ACCEPT / CONFIRM / RETRY
            |
            v
 Translation / UI / Avatar
```

The MCIE source code is responsible for:

- interpreting doctor speech payloads from the ASR module;
- interpreting patient BIM recognizer Top-K outputs;
- preserving conversation context across turns;
- context-aware candidate selection without inventing recognizer candidates;
- buffering multiple isolated patient signs until **Finish Sentence** is explicitly selected;
- deterministic handling of recognized medical quantities/duration;
- local AI-enhanced semantic reasoning;
- evidence-based validation of LLM concepts;
- `ACCEPT`, `CONFIRM`, and `RETRY` safety decisions;
- producing one stable MCIE output structure for downstream modules.

MCIE **does not diagnose, prescribe, or invent uncertain medical facts**.

## 2. Repository structure

```text
SignBridge_MCIE_AI_V2/
|
├── src/
│   └── signbridge_mcie/
│       ├── __init__.py
│       ├── conversation.py
│       ├── llm_engine.py
│       ├── mcie_ai.py
│       ├── mock_llm.py
│       ├── offline.py
│       ├── patient_bim.py
│       ├── recognizer_adapter.py
│       ├── recognizer_router.py
│       ├── rule_engine.py
│       ├── service.py
│       └── types.py
│
├── examples/
│   ├── simulated_demo.py
│   └── local_qwen_demo.py
│
├── tests/
│   └── test_simulated_mcie.py
│
├── models/
│   └── README.md
│
├── INTEGRATION_CONTRACTS.md
├── requirements.txt
├── requirements-gpu-optional.txt
├── pyproject.toml
└── .gitignore
```

## 3. Main files

### `mcie_ai.py`

Implements the AI-Enhanced MCIE V2 semantic layer. It combines a deterministic rule-based anchor with local LLM output and then validates the AI result before allowing it downstream.

Important safety behaviour:

- allowed intents and concepts are controlled;
- unsupported LLM concepts are removed;
- doctor-speech concepts require source support;
- patient-BIM concepts can only come from supplied BIM concepts or valid conversation context;
- critical medical content can require confirmation;
- invalid AI JSON is not silently accepted.

### `rule_engine.py`

Provides deterministic intent detection, medical concept extraction, basic entities, numeric values, and medication timing/frequency anchors.

Specific medical concepts are checked before generic `PAIN`, preventing an input such as `sakit kepala` from being reduced to generic pain.

### `recognizer_adapter.py`

Adapts the shared Medical V2, General V1, and Number V1 recognizer outputs into MCIE sign tokens.

MCIE consumes Top-K candidates and may rerank **only among candidates returned by the recognizer**. It never invents a new sign candidate.

Raw confidence values from different recognizer models are not compared against one another to choose a model.

### `conversation.py`

Stores conversation context and the patient sentence buffer.

Two kinds of memory are intentionally separated:

1. **temporary patient sign buffer** — isolated signs for the current patient sentence;
2. **conversation context** — information such as the active symptom and previous doctor intent across turns.

### `patient_bim.py`

Builds a complete patient message after the UI explicitly sends **Finish Sentence**.

For duration responses, recognized quantity semantics are kept deterministic. For example:

```text
Doctor: "Sakit kepala sejak bila?"
Patient signs: 2 + hari
MCIE: HEADACHE + 2 DAY
Output: "I have had a headache for 2 days."
```

The LLM is not allowed to change a recognized quantity such as `2` into another number.

### `service.py`

Provides the recommended public API for integrating MCIE into the final SignBridge application:

```python
runtime.process_doctor_asr_payload(...)
runtime.expected_recognizer_domains(...)
runtime.start_patient_sentence()
runtime.preview_patient_sign(...)
runtime.accept_patient_sign(...)
runtime.remove_last_patient_sign()
runtime.finish_patient_sentence()
runtime.cancel_patient_sentence()
```

## 4. Stable MCIE output contract

Both doctor and patient paths use the same structure:

```json
{
  "success": true,
  "source": "doctor_speech",
  "input": {},
  "interpretation": {
    "intent": "SYMPTOM_CHECK",
    "medical_concepts": ["FEVER"],
    "entities": {},
    "context_used": false
  },
  "output": {
    "simplified_text_en": "Do you have a fever?",
    "simplified_text_ms": "Adakah anda demam?"
  },
  "safety": {
    "decision": "ACCEPT",
    "requires_confirmation": false,
    "requires_retry": false,
    "reasons": []
  },
  "metadata": {
    "engine": "AI_ENHANCED_MCIE_V2"
  },
  "ready_for_output": true,
  "ready_for_translation": true
}
```

The patient path uses `"source": "patient_bim"`.

## 5. Patient sentence buffering

The current BIM models recognize one isolated sign per capture. MCIE therefore accumulates accepted sign tokens:

```text
Start Sentence
      |
      v
Capture one sign -> Preview -> Confirm if required -> Add Sign
      |
      +---- repeat for more signs ----+
      |                               |
      +-------------------------------+
      |
      v
Finish Sentence
      |
      v
MCIE interprets complete buffered sequence
```

MCIE does **not** infer sentence completion from a pause or timeout. The authoritative boundary is the explicit **Finish Sentence** action from the UI.

## 6. Recognizer routing

Routing is driven by semantic conversation context, not cross-model softmax comparison.

Examples:

```text
SYMPTOM_DURATION -> Number + General
SYMPTOM_LOCATION -> Medical + General
MEDICATION_QUERY -> Medical + General
SYMPTOM_CHECK -> General response
```

For duration, the final application should preferably route sequentially by expected semantic slot:

```text
NUMBER -> Number recognizer
TIME_UNIT -> General recognizer
```

## 7. Offline operation

The production AI model is loaded locally through `LocalTransformersLLM`.

The loader uses:

```python
local_files_only=True
```

and `offline.py` enables:

```text
HF_HUB_OFFLINE=1
TRANSFORMERS_OFFLINE=1
HF_DATASETS_OFFLINE=1
```

The repository does **not** contain the Qwen model weights because they are large binary model files. Copy the complete model to the final prototype hardware separately.

The intended model is:

```text
Qwen/Qwen3-4B-Instruct-2507
```

stored locally, for example:

```text
models/Qwen3-4B-Instruct-2507/
```

No cloud API is required during runtime.

## 8. Installation

Python 3.10+ is recommended.

```bash
python -m venv .venv
```

Windows:

```bash
.venv\Scripts\activate
```

Linux/macOS:

```bash
source .venv/bin/activate
```

Install:

```bash
pip install -r requirements.txt
pip install -e .
```

For a compatible NVIDIA GPU and 4-bit loading:

```bash
pip install -r requirements-gpu-optional.txt
```

## 9. Run simulated tests

The automated tests use a deterministic mock LLM and simulated upstream JSON payloads. They do **not** claim end-to-end BIM or ASR recognition accuracy.

Run:

```bash
python -m unittest discover -s tests -v
```

The tests cover:

- confirmed doctor chest-pain payload;
- ASR confirmation gating;
- specific `HEADACHE` duration context;
- Top-K contextual reranking bounded to returned candidates;
- confirmation of medically meaningful numbers;
- patient sentence buffer and explicit finish;
- deterministic `2 + DAY` duration output;
- blocking unsupported/invented AI patient concepts;
- critical medication-sign confirmation;
- empty sentence protection.

## 10. Run the simulated demo

```bash
python examples/simulated_demo.py
```

This demo does not require Wi-Fi, Qwen, a microphone, camera, or recognizer model.

## 11. Run with the real local Qwen model

```bash
python examples/local_qwen_demo.py --model-dir "models/Qwen3-4B-Instruct-2507"
```

The model directory must already exist locally.

## 12. Upstream interfaces

MCIE expects data produced by other SignBridge components rather than directly owning those components.

### Doctor ASR

Minimum important fields:

```json
{
  "success": true,
  "source": "doctor_speech",
  "transcript": "You ada sakit dada tak?",
  "medical_validation": {
    "status": "CONFIRM",
    "risk_level": "MEDICAL",
    "detected_concepts": ["CHEST_PAIN"]
  },
  "confirmation_status": "CONFIRMED"
}
```

### Patient BIM recognizers

Shared important fields:

```json
{
  "recognizer": "SignBridge_Medical_Recognizer_V2",
  "domain": "medical",
  "top1": {},
  "top_k": [],
  "confidence_margin": 0.0,
  "quality": {}
}
```

Medical V2 can additionally provide `decision` (`ACCEPT`, `CONFIRM`, or `VERIFY`).

## 13. Safety and limitations

This is a prototype healthcare communication system, not a clinical decision-support or diagnostic system.

Important limitations:

- recognizer confidence is not treated as clinical confidence;
- current recognizers operate on isolated signs rather than continuous BIM sentences;
- sentence completion is manually indicated by the patient/UI;
- LLM output is validated and can be blocked or confirmation-gated;
- medically meaningful quantities require human verification where configured;
- context-based reranking cannot introduce a candidate absent from Top-K;
- the repository's simulated tests validate MCIE behaviour and interfaces, not end-to-end recognition accuracy;
- real-device testing with local ASR, local Qwen, real BIM videos, and the final UI remains a separate integration-validation stage.

## 14. Team integration boundary

This repository intentionally excludes source/models owned by other SignBridge members, including:

- Malaysian Whisper ASR runtime/model;
- Medical BIM Recognizer V2 implementation/model;
- General BIM Recognizer V1 implementation/model;
- Number BIM Recognizer V1 implementation/model;
- Text-to-BIM implementation owned by another module if maintained separately;
- Unity avatar project/assets.

Their outputs are represented by integration contracts and simulated fixtures only.

## 15. Academic / competition note

This repository is intended to document the source code for the MCIE contribution to the SignBridge prototype. AI tools were used during development and debugging; the project's Nexus Log should separately document where AI assistance was used, what errors/limitations were identified, and what was manually verified or corrected.

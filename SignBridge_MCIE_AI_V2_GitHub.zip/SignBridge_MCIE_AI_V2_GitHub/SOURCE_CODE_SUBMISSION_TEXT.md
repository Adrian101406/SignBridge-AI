# Suggested proposal entry

## Source Code – AI-Enhanced MCIE V2

The source code for the Medical Conversation Intelligence Engine (MCIE), including the rule-based semantic anchor, local AI reasoning layer, evidence validator, conversation-state management, recognizer Top-K integration, patient sentence buffering, context-based recognizer routing, and safety decision logic, is available at:

**GitHub:** `https://github.com/<YOUR-USERNAME>/SignBridge-MCIE-AI-V2`

The repository contains the MCIE source code, integration contracts, offline model-loading logic, simulated tests, and example usage. Large AI model weights and teammates' recognizer/ASR/Unity source files are not duplicated in this MCIE repository; those components interface with MCIE through the documented payload contracts.

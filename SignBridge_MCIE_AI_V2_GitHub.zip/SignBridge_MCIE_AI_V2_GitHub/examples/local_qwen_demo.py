"""Minimal production-style offline MCIE startup.

Before running, place the complete local Qwen model directory at the path you
pass on the command line. No model is downloaded by this script.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from signbridge_mcie import AIEnhancedMCIE, MCIERuntime
from signbridge_mcie.llm_engine import LocalTransformersLLM
from signbridge_mcie.offline import enable_offline_mode


parser = argparse.ArgumentParser()
parser.add_argument("--model-dir", required=True, help="Local Qwen3-4B-Instruct-2507 directory")
args = parser.parse_args()

enable_offline_mode()
llm = LocalTransformersLLM(Path(args.model_dir))
runtime = MCIERuntime(AIEnhancedMCIE(llm))

payload = {
    "success": True,
    "source": "doctor_speech",
    "transcript": "U rasa demam tak?",
    "medical_validation": {"status": "PASS", "risk_level": "MEDICAL", "detected_concepts": ["FEVER"]},
    "confirmation_status": "NOT_REQUIRED",
}
print(json.dumps(runtime.process_doctor_asr_payload(payload), indent=2, ensure_ascii=False))

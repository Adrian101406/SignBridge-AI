"""Run without Qwen, webcam, microphone, or Wi-Fi.

This demo verifies the MCIE integration contract using simulated upstream
recognizer payloads. It is not an end-to-end recognition accuracy test.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from signbridge_mcie import AIEnhancedMCIE, MCIERuntime
from signbridge_mcie.mock_llm import DeterministicMockLLM


llm = DeterministicMockLLM({
    "intent": "SYMPTOM_DURATION",
    "medical_concepts": ["HEADACHE"],
    "entities": {
        "symptoms": ["HEADACHE"], "body_parts": [], "medications": [],
        "quantity": None, "frequency": None, "timing": None,
        "duration": {"quantity": None, "unit": None},
    },
    "simplified_text_en": "How long have you had a headache?",
    "simplified_text_ms": "Berapa lama anda mengalami sakit kepala?",
    "context_used": False,
    "evidence": [{"concept": "HEADACHE", "source": "sakit kepala"}],
    "uncertainty": [],
    "requires_confirmation": False,
})

runtime = MCIERuntime(AIEnhancedMCIE(llm))

doctor = runtime.process_doctor_asr_payload({
    "success": True,
    "source": "doctor_speech",
    "transcript": "Sakit kepala sejak bila?",
    "medical_validation": {"status": "PASS", "risk_level": "MEDICAL", "detected_concepts": ["HEADACHE"]},
    "confirmation_status": "NOT_REQUIRED",
})
print("DOCTOR -> MCIE")
print(json.dumps(doctor, indent=2, ensure_ascii=False))
print("\nExpected patient recognizer domains:", runtime.expected_recognizer_domains())

runtime.start_patient_sentence()
number = {
    "recognizer": "SignBridge_Number_Recognizer_V1", "domain": "number",
    "top1": {"class_id": 2, "gloss": "2", "english": "2", "confidence": 0.94},
    "top_k": [
        {"rank": 1, "class_id": 2, "gloss": "2", "english": "2", "confidence": 0.94},
        {"rank": 2, "class_id": 3, "gloss": "3", "english": "3", "confidence": 0.03},
    ],
    "confidence_margin": 0.91,
    "quality": {"hand_presence": 0.98, "raw_frames": 50, "trimmed_frames": 49},
}
day = {
    "recognizer": "SignBridge_General_Recognizer_V1", "domain": "general",
    "top1": {"class_id": 45, "gloss": "hari", "english": "day", "confidence": 0.91},
    "top_k": [
        {"rank": 1, "class_id": 45, "gloss": "hari", "english": "day", "confidence": 0.91},
        {"rank": 2, "class_id": 52, "gloss": "jam", "english": "hour", "confidence": 0.04},
    ],
    "confidence_margin": 0.87,
    "quality": {"hand_presence": 0.96, "raw_frames": 65, "trimmed_frames": 50},
}

number_token = runtime.preview_patient_sign(number, number_is_medical=True, number_confirmed=True)
runtime.accept_patient_sign(number_token)
runtime.accept_patient_sign(runtime.preview_patient_sign(day))
print("\nPATIENT BUFFER")
print(json.dumps(runtime.patient_sentence_preview(), indent=2, ensure_ascii=False))

patient = runtime.finish_patient_sentence()
print("\nFINISHED PATIENT SENTENCE -> MCIE")
print(json.dumps(patient, indent=2, ensure_ascii=False))
